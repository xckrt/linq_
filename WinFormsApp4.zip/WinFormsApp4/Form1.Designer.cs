﻿namespace WinFormsApp4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            listBox1 = new ListBox();
            searchButton = new Button();
            listBox2 = new ListBox();
            button1 = new Button();
            listBox3 = new ListBox();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(12, 11);
            label1.Name = "label1";
            label1.Size = new Size(226, 30);
            label1.TabIndex = 0;
            label1.Text = "Люди младше 40 лет";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(12, 44);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(366, 214);
            listBox1.TabIndex = 1;
            // 
            // searchButton
            // 
            searchButton.Location = new Point(126, 290);
            searchButton.Name = "searchButton";
            searchButton.Size = new Size(175, 23);
            searchButton.TabIndex = 4;
            searchButton.Text = "Добавить";
            searchButton.UseVisualStyleBackColor = true;
            searchButton.Click += searchButton_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(384, 14);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(404, 214);
            listBox2.TabIndex = 5;
            // 
            // button1
            // 
            button1.Location = new Point(518, 235);
            button1.Name = "button1";
            button1.Size = new Size(175, 23);
            button1.TabIndex = 6;
            button1.Text = "задание А";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listBox3
            // 
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 15;
            listBox3.Location = new Point(422, 270);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(366, 139);
            listBox3.TabIndex = 7;
            // 
            // button2
            // 
            button2.Location = new Point(518, 415);
            button2.Name = "button2";
            button2.Size = new Size(175, 23);
            button2.TabIndex = 8;
            button2.Text = "задание Б";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(listBox3);
            Controls.Add(button1);
            Controls.Add(listBox2);
            Controls.Add(searchButton);
            Controls.Add(listBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBox1;
        private Button searchButton;
        private ListBox listBox2;
        private Button button1;
        private ListBox listBox3;
        private Button button2;
    }
}