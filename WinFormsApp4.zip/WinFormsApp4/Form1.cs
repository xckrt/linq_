using System;
using System.Security.Cryptography;

namespace WinFormsApp4
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        List<Department> departments = new List<Department>
            {
                new Department { Name = "����� �������", Reg = "��������" },
                new Department { Name = "����� ������", Reg = "�������" },
                new Department { Name = "����� ����������", Reg = "�������" }
            };
        List<Employee> employees = new List<Employee>
            {
                new Employee { Name = "������", Department = "����� �������" },
                new Employee { Name = "������", Department = "����� �������" },
                new Employee { Name = "�������", Department = "����� ������" },
                new Employee { Name = "�����", Department = "����� ������" },
                new Employee { Name = "���������", Department = "����� ����������" },
                new Employee { Name = "����������", Department = "����� ������" }
            };
        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void searchButton_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "��������� ����� (*.txt)|*.txt";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;


                List<People> people = ReadPeopleFromFile(filePath);


                var youngPeople = from person in people
                                  where person.Age < 40
                                  select person;

                
                listBox1.Items.Clear();

                
                foreach (var person in youngPeople)
                {
                    listBox1.Items.Add($"{person.LastName} {person.FirstName} {person.MiddleName}, �������: {person.Age}, ���: {person.Weight}");
                }
            }
        }


        private List<People> ReadPeopleFromFile(string filePath)
        {
            List<People> people = new List<People>();

            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;

                while (!reader.EndOfStream)
                {
                    line = reader.ReadLine();
                    string[] parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    string lastName = parts[0];
                    string firstName = parts[1];
                    string middleName = parts[2];
                    int age = int.Parse(parts[3]);
                    int weight = int.Parse(parts[4]);
                    People person = new People();
                    person.Weight = weight;
                    person.FirstName = firstName;
                    person.MiddleName = middleName;
                    person.LastName = lastName;
                    person.Age = age;
                    people.Add(person);
                }
            }

            return people;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var groupedEmployees = from employee in employees
                                   join department in departments on employee.Department equals department.Name
                                   group employee by department into grouped
                                   select new
                                   {
                                       DepartmentName = grouped.Key.Name,
                                       Employees = grouped.Select(emp => emp.Name).ToList()
                                   };

            
            listBox2.Items.Clear();

            
            foreach (var group in groupedEmployees)
            {
                listBox2.Items.Add($"�����: {group.DepartmentName}");
                foreach (var employee in group.Employees)
                {
                    listBox2.Items.Add($"  - {employee}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var filteredEmployees = from employee in employees
                                    join department in departments on employee.Department equals department.Name
                                    where department.Reg.StartsWith("�")
                                    select employee;

            
            listBox3.Items.Clear();

            
            foreach (var employee in filteredEmployees)
            {
                listBox3.Items.Add(employee.Name);
            }
        }
    }
}
    




