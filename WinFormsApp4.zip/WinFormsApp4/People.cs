﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp4
{
    public class People
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }   
        public string MiddleName { get; set; }
        public int Age { get; set; }
        public int Weight { get; set; }
    }
    class Department
    {
        public string Name { get; set;}
        public string Reg { get; set;  }
    }

    
    class Employee
    {
        public string Name { get; set; }
        public string Department { get; set; }
    }

}
